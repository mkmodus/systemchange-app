
// 이 파일은 더 이상 사용되지 않습니다.
export const Visualizer = () => null;
